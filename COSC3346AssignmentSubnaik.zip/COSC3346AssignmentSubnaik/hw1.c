#include <stdio.h>
#include "hw1.h"


int main()
{


  printf("%s",msg);

  return 0;
}