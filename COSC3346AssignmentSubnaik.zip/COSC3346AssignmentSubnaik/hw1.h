#ifndef HW_H
#define HW_H

char * msg = "hello world\n";


#endif